import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate, useLocation } from 'react-router-dom';

const OrdersPage = () => {
  const [orders, setOrders] = useState([]);
  const customerId = sessionStorage.getItem("id");
  const navigate = useNavigate();
  const location = useLocation();
  const totalAmount = location.state?.totalAmount || 0; // Get totalAmount from state if passed
  console.log("Amount received: " ,totalAmount);

  const handleTransaction = (order) => {
    navigate("/Transaction", {
      state: {
        orderId: order.orderId,
        amount: totalAmount, 
      },
    });
  };
  const handleDelete=(order)=>{
    navigate("/DeleteOrder",{
      state:{
        orderId: order.orderId,
      }
    })
  }

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const response = await axios.get(`http://localhost:5263/api/Order/GetOrder/${customerId}`, {
          headers: {
            Authorization: `Bearer ${sessionStorage.getItem('token')}`,
          },
        });
        setOrders(response.data);
        console.log("Fetched orders:", response.data);
      } catch (error) {
        console.error("Error fetching orders", error);
      }
    };
    fetchOrders();
  }, [customerId]);

  return (
    <div className="container mt-4">
        <button onClick={()=>navigate("/GetAllProducts")}>Back</button>
        {orders.length > 0 ? (
      orders.map(order => (
        <div key={order.orderId} className="order-card mb-4 p-3 shadow rounded">
          <h3 className="text-primary">Order ID: {order.orderId}</h3>
          <p><strong>Status:</strong> {order.orderStatus}</p>
          <p><strong>Date of Order:</strong>{new Date(order.dateOfDelivery).toLocaleDateString()}</p>

          <h4>Delivery Details</h4>
          <table className="table table-bordered">
            <tbody>
              <tr>
                <th>Name</th>
                <td>{order.customer.firstName} {order.customer.lastName}</td>
              </tr>             
              <tr>
                <th>Phone</th>
                <td>{order.customer.phoneNumber}</td>
              </tr>
              <tr>
                <th>Address</th>
                <td>{order.customer.address}, {order.customer.city}, {order.customer.state}, {order.customer.postalCode}</td>
              </tr> 
            </tbody>
          </table>

          <h4>Order Items</h4>
          <table className="table table-striped">
            <thead className="thead-dark">
              <tr>
                <th>Product ID</th>
                <th>Quantity</th>
                <th>Price</th>
                <th>Discount (%)</th>
                <th>Expected Date of Delivery</th>
              </tr>
            </thead>
            <tbody>
              {order.orderItems.map(item => (
                <tr key={item.itemId}>
                  <td>{item.productId}</td>
                  <td>{item.quantity}</td>
                  <td>{item.price}</td>
                  <td>{item.discount}</td>
                  <td>{new Date(new Date(order.dateOfDelivery).setDate(new Date(order.dateOfDelivery).getDate() + 5)).toLocaleDateString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <p>Total Amount:{totalAmount}</p>
          <button className='btn btn-danger' onClick={()=>handleDelete(order)}>Delete Order</button>
          <button className="btn btn-success" onClick={()=> handleTransaction(order)}>Make Payment</button>
        </div>
      ))):(<h2>No Products</h2>)
    }
    </div>
  );
};

export default OrdersPage;
