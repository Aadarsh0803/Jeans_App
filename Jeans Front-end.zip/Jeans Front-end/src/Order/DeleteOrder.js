import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const DeleteOrder = () => {
  const [orders, setOrders] = useState([]);
  const navigate = useNavigate();
  const customerId = sessionStorage.getItem("id");

  useEffect(() => {
    // Fetch all orders from the backend
    const fetchOrders = async () => {
      try {
        const response = await axios.get(`http://localhost:5263/api/Order/GetOrder/${customerId}`, {
          headers: {
            Authorization: `Bearer ${sessionStorage.getItem("token")}`,
          },
        });
        setOrders(response.data);
      } catch (error) {
        console.error("Error fetching orders:", error);
      }
    };

    fetchOrders();
  }, []);

  // Function to delete an order
  const deleteOrder = async (orderId) => {
    if (window.confirm("Are you sure you want to delete this order?")) {
      try {
        await axios.delete(`http://localhost:5263/api/Order/DeleteOrder/${orderId}`, {
          headers: {
            Authorization: `Bearer ${sessionStorage.getItem("token")}`,
          },
        });
        alert("Order deleted successfully!");

        // Update the UI after deleting
        setOrders(orders.filter((order) => order.orderId !== orderId));
      } catch (error) {
        console.error("Error deleting the order:", error);
        alert("Error deleting the order.");
      }
    }
  };

  return (
    <div className="container mt-4">
      <h2>Orders List</h2>
      <button onClick={() => navigate("/WelcomePage")}>Back</button>

      {orders.length > 0 ? (
        orders.map((order) => (
          <div key={order.orderId} className="order-card mb-4 p-3 shadow rounded">
            <h3 className="text-primary">Order ID: {order.orderId}</h3>
            <p><strong>Status:</strong> {order.orderStatus}</p>
            <p><strong>Date of Order:</strong> {new Date(order.dateOfDelivery).toLocaleDateString()}</p>

            <h4>Delivery Details</h4>
            <p>Name: {order.customer.firstName} {order.customer.lastName}</p>

            {/* Button to delete an order */}
            <button
              className="btn btn-danger"
              onClick={() => deleteOrder(order.orderId)}
            >
              Delete Order
            </button>
          </div>
        ))
      ) : (
        <h2>No Orders Available</h2>
      )}
    </div>
  );
};

export default DeleteOrder;
