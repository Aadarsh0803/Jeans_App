import React from "react";

const CustomerDashBoard=()=>{
    return(
        <h1>Customer</h1>
    )
}

export default CustomerDashBoard