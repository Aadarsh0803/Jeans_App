import React, { useState, useEffect } from 'react';
import axios from 'axios';

const OrdersAdmin = () => {
  const [orders, setOrders] = useState([]);
  const [filteredOrders, setFilteredOrders] = useState([]);
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  // Fetch order data from backend on component mount
  useEffect(() => {
    axios.get('http://localhost:5263/api/Order/GetAllOrders', {
      headers: {
        Authorization: `Bearer ${sessionStorage.getItem('token')}`
      }
    })
    .then((res) => {
      setOrders(res.data);
      setFilteredOrders(res.data);  // Initialize filtered orders with full data
    })
    .catch((err) => {
      console.error(err);
    });
  }, []);

  // Filter orders by date range
  const filterOrders = () => {
    if (startDate && endDate) {
      const filtered = orders.filter(order => {
        const orderDate = new Date(order.dateOfDelivery);
        return orderDate >= new Date(startDate) && orderDate <= new Date(endDate);
      });
      setFilteredOrders(filtered);
    } else {
      setFilteredOrders(orders); // If no dates provided, reset to full list
    }
  };

  return (
    <div>
      <h2>Order List</h2>
      
      {/* Date Filter */}
      <div style={{ marginBottom: '20px' }}>
        <label>Start Date: </label>
        <input
          type="date"
          value={startDate}
          onChange={(e) => setStartDate(e.target.value)}
        />
        <label>End Date: </label>
        <input
          type="date"
          value={endDate}
          onChange={(e) => setEndDate(e.target.value)}
        />
        <button onClick={filterOrders} className="btn btn-primary">
          Filter Orders
        </button>
      </div>

      {/* Orders Table */}
      <table className="table table-bordered">
        <thead>
          <tr>
            <th>Order ID</th>
            <th>Customer Name</th>
            <th>Date of Order</th>
            <th>Order Status</th>
            <th>Items</th>
          </tr>
        </thead>
        <tbody>
          {filteredOrders.map((order) => (
            <tr key={order.orderId}>
              <td>{order.orderId}</td>
              <td>{order.customer.firstName} {order.customer.lastName}</td>
              <td>{new Date(order.dateOfDelivery).toLocaleDateString()}</td>
              <td>{order.orderStatus}</td>
              <td>
                <ul>
                  {order.orderItems.map((item) => (
                    <li key={item.itemId}>
                      Product ID: {item.productId}, Quantity: {item.quantity}, Price: {item.price}, Discount: {item.discount}%
                    </li>
                  ))}
                </ul>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default OrdersAdmin;
