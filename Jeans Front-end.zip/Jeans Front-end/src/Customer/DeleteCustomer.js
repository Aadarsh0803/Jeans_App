import { useState } from "react";
import axios from "axios";
import 'bootstrap/dist/css/bootstrap.min.css';

const DeleteCustomer = () => {
  const [email, setEmail] = useState("");
  const [customer, setCustomer] = useState(null);
  const [errorMessage, setErrorMessage] = useState("");

  // Fetch customer details based on email
  const fetchCustomer = (e) => {
    e.preventDefault();
    setErrorMessage("");

    axios
      .get(`http://localhost:5263/api/Customer/GetCustomerByEmail/${encodeURIComponent(email)}`)
      .then((res) => {
        if (res.data) {
          setCustomer(res.data);
        } else {
          setErrorMessage("No customer found with this email.");
        }
      })
      .catch((err) => {
        console.log(err);
        setErrorMessage("Error fetching customer details.");
      });
  };

  // Handle delete action
  const deleteCustomer = () => {
    if (window.confirm("Are you sure you want to delete this customer?")) {
      axios
        .delete(`http://localhost:5263/api/Customer/Delete/${customer.email}`, {
          headers: {
            Authorization: `Bearer ${sessionStorage.getItem('token')}`, // Replace with actual key for auth token
          },
        })
        .then((res) => {
          console.log(res.data);
          setCustomer(null);
          setEmail("");
          alert("Customer deleted successfully.");
        })
        .catch((err) => {
          console.log(err);
          setErrorMessage("Error deleting customer.");
        });
    }
  };

  return (
    <div className="container mt-4">
      <form onSubmit={fetchCustomer} className="mb-4">
        <div className="form-group">
          <label htmlFor="email">Enter Customer Email:</label>
          <input
            type="email"
            id="email"
            className="form-control form-control-sm" // Reduced size
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        <button type="submit" className="btn btn-primary">Fetch Customer</button>
      </form>

      {errorMessage && <div className="alert alert-danger">{errorMessage}</div>}

      {customer && (
        <div>
          <h4>Customer Details</h4>
          <ul className="list-group">
            <li className="list-group-item">Customer ID: {customer.customerId}</li>
            <li className="list-group-item">Name: {customer.firstName} {customer.lastName}</li>
            <li className="list-group-item">Email: {customer.email}</li>
            <li className="list-group-item">Phone Number: {customer.phoneNumber}</li>
            <li className="list-group-item">Address: {customer.address}</li>
            <li className="list-group-item">City: {customer.city}</li>
            <li className="list-group-item">State: {customer.state}</li>
            <li className="list-group-item">Postal Code: {customer.postalcode}</li>
            <li className="list-group-item">Country: {customer.country}</li>
          </ul>
          <button className="btn btn-danger mt-3" onClick={deleteCustomer}>Delete Customer</button>
        </div>
      )}
    </div>
  );
};

export default DeleteCustomer;
