
import './App.css';
import AddProduct from './Product/AddProduct';
import {BrowserRouter,Route,Routes} from 'react-router-dom'
import Login from './start/Login';
import GetAllProducts from './Product/GetAllProducts';
import FilterProducts from './Product/FilterProduct';
import AdminDashboard from './Customer/AdminDashBoard';
import Register from './start/Register';
import Start from './start/Start';
import GetAllCustomers from './Customer/GetAllCustomer'
import WelcomePage from './WelcomePage';
import GetCustomer from './Customer/Profile';
import Logout from './start/LogOut';
import WelcomeAdmin from './WelcomeAdmin';
import AddCart from './Product/AddCart';
import GetCart from './Product/GetCart';
import GetWishList from './WishList/GetWishList';
import AddWish from './WishList/AddWishList';
import DeleteWish from './WishList/DEleteWish';
import AddOrder from './Order/AddOrder';
import EditCustomer from './Customer/EditCustomer';
import DeleteProduct from './Product/DeleteProduct';
import RemoveCart from './Product/RemoveCart';
import GetOrders from './Order/GetOrders';
import GetProductById from './Product/GetProductById';
import EditCustomerSelf from './Customer/EditCustomerSelf';
import Transaction from './Essentials/AddTransaction';
import GetAllProductsAdmin from './Customer/GetAllProductsAdmin';
import UpdateProduct from './Product/EditProduct';
import OrdersAdmin from './Customer/GetOrdersAdmin';
import GetTransaction from './Essentials/GetTransaction';
import ProductList from './Product/FilterProduct';
import DeleteOrder from './Order/DeleteOrder';
import GetTransactions from './Essentials/GetTransaction';


function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route index element={<Start/>}></Route>
          <Route path='Register' element={<Register/>}></Route>
          <Route path='Login' element={<Login/>}></Route>
        </Routes>      
      </BrowserRouter>
      {/* Admin */}

      <BrowserRouter>
      <Routes>
        <Route index element={<AdminDashboard/>}></Route>
        <Route path='WelcomeAdmin' element={<WelcomeAdmin/>}/>
        <Route path='AddProduct' element={<AddProduct/>}/>
        <Route path='GetAllProducts' element={<GetAllProducts/>}/>
        <Route path='FilterProducts' element={<FilterProducts/>}/>
        <Route path='GetAllCustomers' element={<GetAllCustomers/>}/>
        <Route path='GetAllProductsAdmin' element={<GetAllProductsAdmin/>}/>
        <Route path='UpdateProduct' element={<UpdateProduct/>}/>
        <Route path='OrdersAdmin' element={<OrdersAdmin/>}/>
        <Route path='ProductList' element={<ProductList/>}/>
        </Routes>
      </BrowserRouter>

      {/* Customer */}
      <BrowserRouter>
      <Routes>
        {/* <Route index element={<CustomerDashBoard/>}/> */}
        <Route path='WelcomePage' element={<WelcomePage/>}/>
        <Route path='GetCustomer' element={<GetCustomer/>}/>
        <Route path='EditCustomer' element={<EditCustomer/>}/>
        <Route path='Logout' element={<Logout/>}></Route>
        <Route path='WishList' element={<GetWishList/>}/>
        <Route path='AddWish' element={<AddWish/>}/>
        <Route path='DeleteWish' element={<DeleteWish/>}/>
        <Route path='AddOrder' element={<AddOrder/>}/>
        <Route path='RemoveCart' element={<RemoveCart/>}/>
        <Route path='GetOrders' element={<GetOrders/>}/>
        <Route path='GetProductById' element={<GetProductById/>}/>
        <Route path='EditCustomerSelf' element={<EditCustomerSelf/>}/>
        <Route path='Transaction' element={<Transaction/>}/>
        <Route path='GetTransaction' element={<GetTransaction/>}/>
        <Route path='GetTransactions' element={<GetTransactions/>}/>
        <Route path='AddCart' element={<AddCart/>}/>
        <Route path='DeleteOrder' element={<DeleteOrder/>}/>
      </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
