import { useEffect, useState } from "react";
import React from "react";
import { Link } from "react-router-dom";
import JeansAdMen from './images/JeansAdMen.jpg';  // Import your images
import JeansWomen from './images/JeansWomen.jpg';
import JeansMain from './images/JeansMain.jpg';

const WelcomePage = () => {
  const [currentIndex, setCurrentIndex] = useState(0);

  const images = [JeansAdMen, JeansWomen, JeansMain];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prevIndex) =>
        prevIndex === images.length - 1 ? 0 : prevIndex + 1
      );
    }, 3000); 

    return () => clearInterval(interval); 
  }, [images.length]);



  return (
    <>
      <nav className="navbar navbar-expand-lg navbar-light bg-light">
        <div className="container-fluid">
            JeansApp
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarNav"
            aria-controls="navbarNav"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarNav">
            <ul className="navbar-nav">
              <li className="nav-item">
                <Link className="nav-link" to="/GetAllProducts">
                  Products
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/GetOrders">
                  Orders
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/GetCart">
                  Cart
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/WishList">
                  WishList
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/GetCustomer">
                  Profile
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/Logout">
                  Logout
                </Link>
              </li>
            </ul>
          </div>
        </div>
      </nav>

      <div className="container mt-5">
        <h1>Welcome</h1>
        <p>Explore our wide range of jeans</p>
      </div>

      <div className="carousel-container">
        <img src={images[currentIndex]} alt={`Jeans ${currentIndex}`} className="carousel-image" />
      </div>
    </>
  );
};

export default WelcomePage;
