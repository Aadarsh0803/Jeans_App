import axios from "axios";
import { useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";

const Transaction = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const { orderId, amount } = location.state || {};
  console.log("Received orderId:", orderId);
  console.log("Received amount:", amount);
  const handleTransaction = () => {
    navigate("/GetTransactions", {
      state: {
        orderId: transaction.orderId, // Send the orderId from the transaction state
      },
    });
    console.log("sending order Id: " ,orderId);
  };
  


  const save = async (e) => {
    e.preventDefault();
    console.log("Transaction data before sending:", transaction);
    

    try {
      const response = await axios.post("http://localhost:5263/api/Transaction/AddTransaction", transaction, {
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        },
      });
      console.log("Response from AddTransaction:", response.data);
      const TransactionId = response.data.transactionId;
      setTransaction((prevTransaction)=>({
        ...prevTransaction,
        transactionId:TransactionId,
      }));
      alert("Transaction Successful");
      // navigate("/GetTransaction");
    } catch (err) {
      console.error("Error during transaction:", err);
    }
  };
  const [transaction, setTransaction] = useState({
    orderId: orderId || "",
    customerId: sessionStorage.getItem("id"), 
    amount: 0,
    transactionMethod: "",
    transactionDate: new Date().toISOString(),
  });


  const handleChange = (e) => {
    const { name, value } = e.target;
    console.log(`Input change - ${name}:`, value);
    
    setTransaction((prevTransaction) => ({
      ...prevTransaction,
      [name]: value,
    }));
  };



  return (
    <div className="container">
      <h2>Transaction</h2>
      <form onSubmit={save}>
        <div className="mb-3">
          <label htmlFor="orderId" className="form-label">Order ID</label>
          <input
            type="text"
            className="form-control"
            id="orderId"
            name="orderId"
            value={transaction.orderId}
            readOnly
          />
        </div>

        <div className="mb-3">
          <label htmlFor="customerId" className="form-label">Customer ID</label>
          <input
            type="text"
            className="form-control"
            id="customerId"
            name="customerId"
            value={transaction.customerId}
            readOnly
          />
        </div>




        <div className="mb-3">
          <label htmlFor="transactionMethod" className="form-label">Transaction Method</label>
          <select
            className="form-select"
            id="transactionMethod"
            name="transactionMethod"
            value={transaction.transactionMethod}
            onChange={handleChange}
            required
          >
            <option value="">Select Payment Method</option>
            <option value="COD">Cash on Delivery (COD)</option>
            <option value="GPAY">Google Pay (GPay)</option>
            <option value="PHONEPE">PhonePe</option>
            <option value="PAYTM">Paytm</option>
            <option value="CARD">Credit/Debit Card</option>
          </select>
        </div>
        <div className="mb-3">
          <label htmlFor="transactionDate" className="form-label">Transaction Date</label>
          <input
            type="text"
            className="form-control"
            id="transactionDate"
            name="transactionDate"
            value={new Date(transaction.transactionDate).toLocaleString()}
            readOnly
          />
        </div>

        <button onClick={handleTransaction} className="btn btn-primary">Make Payment</button>
      </form>
    </div>
  );
};

export default Transaction;
