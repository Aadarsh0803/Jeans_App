import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useLocation, useNavigate } from 'react-router-dom';

const GetTransactions = () => {
  const [transactions, setTransactions] = useState([]);
  const location = useLocation();
  const navigate = useNavigate();

  const { orderId } = location.state || {};
  console.log("OrderId :",orderId)

  useEffect(() => {
    if (orderId) {
      axios.get(`http://localhost:5263/api/Transaction/GetTransactionsByOrderId/${orderId}`, {
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem('token')}`,
        },
      })
      .then((res) => {
        console.log("Received transactions:", res.data);
        setTransactions(res.data);
      })
      .catch((err) => console.error("Error fetching transactions:", err));
    }
  }, [orderId]);

  return (

    <div className="container mt-4">
      <h2>Transactions</h2>
      {transactions.length > 0 ? (
        <table className="table table-bordered">
          <thead>
            <tr>
              <th>Transaction ID</th>
              <th>Order ID</th>
              <th>Customer ID</th>
              <th>Amount</th>
              <th>Transaction Method</th>
              <th>Transaction Date</th>
            </tr>
          </thead>
          <tbody>
            {transactions.map((transaction) => (
              <tr key={transaction.transactionId}>
                <td>{transaction.transactionId}</td>
                <td>{transaction.orderId}</td>
                <td>{transaction.customerId}</td>
                <td>{transaction.amount}</td>
                <td>{transaction.transactionMethod}</td>
                <td>{new Date(transaction.transactionDate).toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
         
        </table> 
      ) : (
        <p>No transactions found for this order.</p>
      )}<button className="btn btn-primary" onClick={()=>navigate("/GetAllProducts")}>Back</button>
    </div>
  );
};

export default GetTransactions;
