import { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const GetCart = () => {
  const [cartlist, setcartlist] = useState([]);
  const [quantities, setQuantities] = useState({});
  const navigate = useNavigate();

  useEffect(() => {
    const token = sessionStorage.getItem("token");
    const id = sessionStorage.getItem("id");
    if (token) {
      axios
        .get("http://localhost:5263/api/Cart/GetCart?customerId=" + id, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        })
        .then((response) => {
          console.log(response.data);
          setcartlist(response.data);

          const initialQuantities = {};
          response.data.forEach(item => {
            initialQuantities[item.productId] = item.quantity;
          });
          setQuantities(initialQuantities);
        })
        .catch((error) => console.log(error));
    }
  }, []);

  const handleRemoveCart = (cartId) => {
    if (window.confirm("Are you sure you want to delete this product from the cart?")) {
      axios
        .delete(`http://localhost:5263/api/Cart/DeleteCart?cartId=${cartId}`, {
          headers: {
            Authorization: `Bearer ${sessionStorage.getItem('token')}`,
          },
        })
        .then((res) => {
          alert("Cart item removed successfully.");
          // Refresh cart list after deletion
          setcartlist(cartlist.filter(item => item.cartId !== cartId));
        })
        .catch((err) => {
          console.error(err);
          alert("Error deleting the product.");
        });
    }
  };

  const handleQuantityChange = (productId, newQuantity) => {
    setQuantities((prevQuantities) => {
      const updatedQuantities = {
        ...prevQuantities,
        [productId]: newQuantity,
      };
      sessionStorage.setItem('quantities', JSON.stringify(updatedQuantities));
      return updatedQuantities;
    });
  };

  return (
    <div className="container cart-container mt-5">
      <button onClick={() => navigate("/WelcomePage")}>Back</button>
      <h2 className="text-center mb-4">Cart List</h2>
      <table className="table table-bordered table-hover">
        <thead className="table-primary">
          <tr>
            <th>Product Name</th>
            <th>Product Description</th>
            <th>Gender</th>
            <th>Cloth Type</th>
            <th>Age Group</th>
            <th>Price</th>
            <th>Discount</th>
            <th>Size</th>
            <th>Color</th>
            <th>Brand</th>
            <th>Quantity</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {cartlist.map((item) => (
            <tr key={item.productId}>
              <td>{item.product.productName}</td>
              <td>{item.product.productDescription}</td>
              <td>{item.product.gender}</td>
              <td>{item.product.cloth}</td>
              <td>{item.product.age}</td>
              <td>{item.product.price}</td>
              <td>{item.product.discount}</td>
              <td>{item.product.size}</td>
              <td>{item.product.color}</td>
              <td>{item.product.brand}</td>
              <td>
                <input
                  type="number"
                  min="1"
                  value={quantities[item.productId] || 1}
                  onChange={(e) => handleQuantityChange(item.productId, e.target.value)}
                />
              </td>
              <td>
                <button onClick={() => handleRemoveCart(item.cartId)} className="btn btn-danger">
                  Remove
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default GetCart;
