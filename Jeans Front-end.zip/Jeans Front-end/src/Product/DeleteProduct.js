import { useState } from "react";
import axios from "axios";
import 'bootstrap/dist/css/bootstrap.min.css';

const DeleteProduct = () => {
  const [productId, setProductId] = useState("");
  const [product, setProduct] = useState(null);
  const [errorMessage, setErrorMessage] = useState("");

  // Fetch product details based on productId
  const fetchProduct = (e) => {
    e.preventDefault();
    setErrorMessage("");

    axios
      .get(`http://localhost:5263/api/Product/GetProducts/${encodeURIComponent(productId)}`)
      .then((res) => {
        if (res.data) {
          setProduct(res.data);
        } else {
          setErrorMessage("No product found with this ID.");
        }
      })
      .catch((err) => {
        console.log(err);
        setErrorMessage("Error fetching product details.");
      });
  };

  // Handle delete action
  const deleteProduct = () => {
    if (window.confirm("Are you sure you want to delete this product?")) {
      axios
        .delete(`http://localhost:5263/api/Product/DeleteProduct/${productId}`, {
          headers: {
            Authorization: `Bearer ${sessionStorage.getItem('token')}`,
          },
        })
        .then((res) => {
          console.log(res.data);
          setProduct(null);
          setProductId("");
          alert("Product deleted successfully.");
        })
        .catch((err) => {
          console.log(err);
          setErrorMessage("Error deleting product.");
        });
    }
  };

  return (
    <>
    
    <div className="container mt-4">
      <form onSubmit={fetchProduct} className="mb-4">
        <div className="form-group">
          <label htmlFor="productId">Enter Product ID:</label>
          <input
            type="text"
            id="productId"
            className="form-control form-control-sm" // Reduced size
            value={productId}
            onChange={(e) => setProductId(e.target.value)}
            required
          />
        </div>
        <button type="submit" className="btn btn-primary">Fetch Product</button>
      </form>

      {errorMessage && <div className="alert alert-danger">{errorMessage}</div>}

      {product && (
        <div>
          <h4>Product Details</h4>
          <ul className="list-group">
            <li className="list-group-item">Product ID: {product.productId}</li>
            <li className="list-group-item">Name: {product.productName}</li>
            <li className="list-group-item">Description: {product.productDescription}</li>
            <li className="list-group-item">Price: {product.price}</li>
            <li className="list-group-item">Discount: {product.discount}</li>
            <li className="list-group-item">Gender: {product.gender}</li>
            <li className="list-group-item">Cloth: {product.cloth}</li>
            <li className="list-group-item">Color: {product.color}</li>
            <li className="list-group-item">Brand: {product.brand}</li>
            <li className="list-group-item">Age: {product.age}</li>
          </ul>
          <button className="btn btn-danger mt-3" onClick={deleteProduct}>Delete Product</button>
        </div>
      )}
    </div>
    </>
      );
};

export default DeleteProduct;
