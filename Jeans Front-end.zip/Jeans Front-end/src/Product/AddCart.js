import React, { useEffect, useState } from "react";
import axios from "axios";
import { useLocation, useNavigate } from "react-router-dom";

const AddCart = () => {
    const location = useLocation();
    const navigate = useNavigate();
    const product = location.state?.product;
    
    const [addCart, setCart] = useState({
        customerId: sessionStorage.getItem("id"),
        productId: product?.productId,
        quantity: 1,
    });
  
    useEffect(() => {
        if (!product) {
            alert("No product selected! Redirecting...");
            navigate("/GetAllProducts");
        }
    }, [product, navigate]);
  
    const saveToCart = () => {
        axios
            .post("http://localhost:5263/api/Cart/AddCart", addCart, {
                headers: {
                    Authorization: `Bearer ${sessionStorage.getItem("token")}`,
                },
            })
            .then((res) => {
                console.log("Response from server:", res.data);
                alert("Product added to cart!");
                navigate("/GetAllProducts");
            })
            .catch((err) => {
                console.error("Error adding product to cart:", err.response?.data || err.message);
                alert("Product already exists in the cart.");
            });
    };
  
    return (
        <div>
            {/* Add form or buttons to handle adding to cart */}
            <button onClick={saveToCart}>Save to Cart</button>
        </div>
    );
};

export default AddCart;
