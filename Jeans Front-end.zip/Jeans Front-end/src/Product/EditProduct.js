import { useState } from "react";
import axios from "axios";
import 'bootstrap/dist/css/bootstrap.min.css';

const UpdateProduct = () => {
    const [product, setProduct] = useState({
        productId: 0,
        productName: "",
        productDescription: "",
        gender: "",
        cloth: "",
        age: "",
        price: 0,
        discount: 0,
        size: 0,
        quantity: 0,
        color: "",
        brand: ""
    });

    const [productIdInput, setProductIdInput] = useState('');
    const [errorMessage,SetMsg] = useState('');

    const fetchProductDetails = () => {
        if (productIdInput) {
            axios.get(`http://localhost:5263/api/Product/GetProducts/${productIdInput}`, {
                headers: {
                    Authorization: `Bearer ${sessionStorage.getItem('token')}`
                }
            })
            .then((res) => {
                if(res.data){
                    setProduct(res.data);
                    SetMsg("");

                }else{
                    SetMsg("No Product Found")
                }
            })
            .catch((err) => console.log(err));
            SetMsg("Error Fetching the product details")
        }
    };

    const save = (event) => {
        event.preventDefault();
        axios.put(`http://localhost:5263/api/Product/UpdateProduct/${product.productId}`, product, {
            headers: {
                Authorization: `Bearer ${sessionStorage.getItem('token')}`
            }
        })
        .then((res) => {
            console.log(res.data);
            SetMsg("");
        })
        .catch((err) => console.log(err));
        SetMsg("Error updating product");
    };

    return (

        <div className="container mt-5">
            <h2 className="mb-4">Update Product</h2>
            <div className="mb-3">
                <label htmlFor="productIdInput" className="form-label">Enter Product ID:</label>
                <input
                    type="text"
                    className="form-control"
                    id="productIdInput"
                    value={productIdInput}
                    onChange={(e) => setProductIdInput(e.target.value)}
                />
                <button className="btn btn-primary mt-2" onClick={fetchProductDetails}>Fetch Product</button>
            </div>
            {errorMessage && <div className="alert alert-danger mt-2">{errorMessage}</div>}

            <form onSubmit={save}>
                <table className="table table-bordered">
                    <tbody>
                        <tr>
                            <td>Product ID</td>
                            <td>
                                <input type="text" 
                                    className="form-control"
                                    value={product.productId}
                                    onChange={(e) =>
                                        setProduct((prevObj) => ({
                                            ...prevObj,
                                            productId: e.target.value,
                                        }))
                                    }
                                    disabled
                                />
                            </td>
                        </tr>
                        <tr>
                            <td>Product Name</td>
                            <td>
                                <input type="text"
                                    className="form-control"
                                    value={product.productName}
                                    onChange={(e) =>
                                        setProduct((prevObj) => ({
                                            ...prevObj,
                                            productName: e.target.value,
                                        }))
                                    }
                                />
                            </td>
                        </tr>
                        <tr>
                            <td>Product Description</td>
                            <td>
                                <input type="text"
                                    className="form-control"
                                    value={product.productDescription}
                                    onChange={(e) =>
                                        setProduct((prevObj) => ({
                                            ...prevObj,
                                            productDescription: e.target.value,
                                        }))
                                    }
                                />
                            </td>
                        </tr>
                        <tr>
                            <td>Gender</td>
                            <td>
                                <input type="text"
                                    className="form-control"
                                    value={product.gender}
                                    onChange={(e) =>
                                        setProduct((prevObj) => ({
                                            ...prevObj,
                                            gender: e.target.value,
                                        }))
                                    }
                                />
                            </td>
                        </tr>
                        <tr>
                            <td>Cloth</td>
                            <td>
                                <input type="text"
                                    className="form-control"
                                    value={product.cloth}
                                    onChange={(e) =>
                                        setProduct((prevObj) => ({
                                            ...prevObj,
                                            cloth: e.target.value,
                                        }))
                                    }
                                />
                            </td>
                        </tr>
                        <tr>
                            <td>Age</td>
                            <td>
                                <input type="text"
                                    className="form-control"
                                    value={product.age}
                                    onChange={(e) =>
                                        setProduct((prevObj) => ({
                                            ...prevObj,
                                            age: e.target.value,
                                        }))
                                    }
                                />
                            </td>
                        </tr>
                        <tr>
                            <td>Price</td>
                            <td>
                                <input type="number"
                                    className="form-control"
                                    value={product.price}
                                    onChange={(e) =>
                                        setProduct((prevObj) => ({
                                            ...prevObj,
                                            price: e.target.value,
                                        }))
                                    }
                                />
                            </td>
                        </tr>
                        <tr>
                            <td>Discount</td>
                            <td>
                                <input type="number"
                                    className="form-control"
                                    value={product.discount}
                                    onChange={(e) =>
                                        setProduct((prevObj) => ({
                                            ...prevObj,
                                            discount: e.target.value,
                                        }))
                                    }
                                />
                            </td>
                        </tr>
                        <tr>
                            <td>Size</td>
                            <td>
                                <input type="number"
                                    className="form-control"
                                    value={product.size}
                                    onChange={(e) =>
                                        setProduct((prevObj) => ({
                                            ...prevObj,
                                            size: e.target.value,
                                        }))
                                    }
                                />
                            </td>
                        </tr>
                        <tr>
                            <td>Quantity</td>
                            <td>
                                <input type="text"
                                    className="form-control"
                                    value={product.quantity}
                                    onChange={(e) =>
                                        setProduct((prevObj) => ({
                                            ...prevObj,
                                            quantity: e.target.value,
                                        }))
                                    }
                                />
                            </td>
                        </tr>
                        <tr>
                            <td>Color</td>
                            <td>
                                <input type="text"
                                    className="form-control"
                                    value={product.color}
                                    onChange={(e) =>
                                        setProduct((prevObj) => ({
                                            ...prevObj,
                                            color: e.target.value,
                                        }))
                                    }
                                />
                            </td>
                        </tr>
                        <tr>
                            <td>Brand</td>
                            <td>
                                <input type="text"
                                    className="form-control"
                                    value={product.brand}
                                    onChange={(e) =>
                                        setProduct((prevObj) => ({
                                            ...prevObj,
                                            brand: e.target.value,
                                        }))
                                    }
                                />
                            </td>
                        </tr>
                    </tbody>
                </table>
                <button type="submit" className="btn btn-success mt-3">Save</button>
            </form>
        </div>
    );
}

export default UpdateProduct;
