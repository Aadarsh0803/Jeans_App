import { useState } from "react";
import axios from "axios";
import 'bootstrap/dist/css/bootstrap.min.css';
import { useNavigate } from "react-router-dom";
const generateItemId = () => {
    const randomId = Math.floor(Math.random() * 1000).toString().padStart(3, "0");
    return `P${randomId}`;
  };
const AddProduct = () => {
    const navigate = useNavigate();
    const [product, setProduct] = useState({
        productId: generateItemId(),
        productName: "",
        productDescription: "",
        gender: "",
        cloth: "",
        age: "",
        price: 0,
        discount: 0,
        size: 0,
        color: "",
        brand: ""
    });

    const save = (e) => {
        e.preventDefault();
        console.log(product);
        axios
            .post("http://localhost:5263/api/Product/AddProduct", product, {
                headers: {
                    Authorization: `Bearer ${sessionStorage.getItem('token')}`
                }
            })
            .then((res) => {
                console.log(res.data);
                alert("Product Added")
            })
            .catch((err) => console.log(err));
    };

    return (
        <div className="container mt-5">
            <button className="btn btn-secondary"  onClick={() => navigate("/WelcomeAdmin")}>Back</button>
            <h2 className="mb-4">Add Product</h2>
            <form onSubmit={save}>
                <table className="table table-bordered">
                    <tbody>
                        <tr>
                            <td>Product ID</td>
                            <td>
                                <input 
                                    type="text" 
                                    className="form-control"
                                    value={product.productId}
                                    onChange={(e) =>
                                        setProduct((prevObj) => ({
                                            ...prevObj,
                                            productId: e.target.value,
                                        }))
                                    }
                                />
                            </td>
                        </tr>
                        <tr>
                            <td>Product Name</td>
                            <td>
                                <input 
                                    type="text" 
                                    className="form-control"
                                    value={product.productName}
                                    onChange={(e) =>
                                        setProduct((prevObj) => ({
                                            ...prevObj,
                                            productName: e.target.value,
                                        }))
                                    }
                                />
                            </td>
                        </tr>
                        <tr>
                            <td>Product Description</td>
                            <td>
                                <input 
                                    type="text" 
                                    className="form-control"
                                    value={product.productDescription}
                                    onChange={(e) =>
                                        setProduct((prevObj) => ({
                                            ...prevObj,
                                            productDescription: e.target.value,
                                        }))
                                    }
                                />
                            </td>
                        </tr>
                        <tr>
                            <td>Gender</td>
                            <td>
                                <input 
                                    type="text" 
                                    className="form-control"
                                    value={product.gender}
                                    onChange={(e) =>
                                        setProduct((prevObj) => ({
                                            ...prevObj,
                                            gender: e.target.value,
                                        }))
                                    }
                                />
                            </td>
                        </tr>
                        <tr>
                            <td>Cloth</td>
                            <td>
                                <input 
                                    type="text" 
                                    className="form-control"
                                    value={product.cloth}
                                    onChange={(e) =>
                                        setProduct((prevObj) => ({
                                            ...prevObj,
                                            cloth: e.target.value,
                                        }))
                                    }
                                />
                            </td>
                        </tr>
                        <tr>
                            <td>Age</td>
                            <td>
                                <input 
                                    type="text" 
                                    className="form-control"
                                    value={product.age}
                                    onChange={(e) =>
                                        setProduct((prevObj) => ({
                                            ...prevObj,
                                            age: e.target.value,
                                        }))
                                    }
                                />
                            </td>
                        </tr>
                        <tr>
                            <td>Price</td>
                            <td>
                                <input 
                                    type="number" 
                                    className="form-control"
                                    value={product.price}
                                    onChange={(e) =>
                                        setProduct((prevObj) => ({
                                            ...prevObj,
                                            price: e.target.value,
                                        }))
                                    }
                                />
                            </td>
                        </tr>
                        <tr>
                            <td>Discount</td>
                            <td>
                                <input 
                                    type="number" 
                                    className="form-control"
                                    value={product.discount}
                                    onChange={(e) =>
                                        setProduct((prevObj) => ({
                                            ...prevObj,
                                            discount: e.target.value,
                                        }))
                                    }
                                />
                            </td>
                        </tr>
                        <tr>
                            <td>Size</td>
                            <td>
                                <input 
                                    type="number" 
                                    className="form-control"
                                    value={product.size}
                                    onChange={(e) =>
                                        setProduct((prevObj) => ({
                                            ...prevObj,
                                            size: e.target.value,
                                        }))
                                    }
                                />
                            </td>
                        </tr>
                       
                        <tr>
                            <td>Color</td>
                            <td>
                                <input 
                                    type="text" 
                                    className="form-control"
                                    value={product.color}
                                    onChange={(e) =>
                                        setProduct((prevObj) => ({
                                            ...prevObj,
                                            color: e.target.value,
                                        }))
                                    }
                                />
                            </td>
                        </tr>
                        <tr>
                            <td>Brand</td>
                            <td>
                                <input 
                                    type="text" 
                                    className="form-control"
                                    value={product.brand}
                                    onChange={(e) =>
                                        setProduct((prevObj) => ({
                                            ...prevObj,
                                            brand: e.target.value,
                                        }))
                                    }
                                />
                            </td>
                        </tr>
                    </tbody>
                </table>
                <button type="submit" className="btn btn-primary">Save</button>
            </form>
        </div>
    );
};

export default AddProduct;
